# Stream Weaver

https://github.com/infometaelektronik-oss/neon-dpad-stream-32f72b6b buprojeyi linkten çek ve # PROJE GELİŞTİRME VE ÖZELLİK EKLEME TALEP DOKUMANI



Mevcut Android TV / Tablet odaklı dizi-film ve canlı yayın akış uygulamamda bazı hataları gidermek, yeni kategoriler eklemek ve admin panelini yapay zeka desteğiyle güçlendirmek istiyorum. Lütfen aşağıdaki geliştirmeleri sırasıyla ve eksiksiz olarak uygula:



---



## 1. Hata Düzeltmeleri & Optimizasyon

* Uygulama genelinde yaşanan kararsızlıkları, çökme hatalarını ve ayrıştırma (parsing) problemlerini tespit ederek kod tabanını optimize et.

* Canlı yayın linklerinin oynatıcıda (Player) stabil çalışmasını sağla, hata veren oynatıcı senaryolarını iyileştir.



## 2. Canlı Yayın ve "Radyo" Kategorisi Ayrıştırması

* Uygulamanın ana arayüzüne ve veri yapısına "Radyo" adında tamamen bağımsız yeni bir kategori ekle.

* Canlı TV yayınları ile Radyo yayınlarını birbirinden tamamen ayır. 

* Canlı yayın linklerini ve radyo istasyonlarını ilgili kategorilere göre dinamik olarak listele.



## 3. Yapay Zeka Destekli Otomatik Link Kontrolü (Link Checker)

* Uygulamanın arka planına (backend) çalışan bir yapay zeka/otomatik kontrol mekanizması entegre et.

* Bu mekanizma, eklenen canlı yayın ve radyo linklerini düzenli olarak arka planda test etmeli; çalışmayan, kırık veya "gebelik olmuş" (patlamış) linkleri otomatik olarak tespit edip sistemden silmeli veya deaktif etmeli.



## 4. Gelişmiş Admin Paneli & Akıllı M3U Yükleme Sistemi

* Admin paneline M3U dosyası yükleyebilmek için yeni bir "Dosya Yükleme ve Akıllı Ayrıştırma" modülü ekle.

* Ben admin panelinden tek bir .m3u dosyasını topluca yüklediğimde, sistem dosya içeriğini teker teker taramalı.

* Yüklenen kanalları M3U içindeki grup etiketlerine (group-title) veya kanal türlerine göre analiz ederek; canlı yayınları "Canlı Yayın" kategorisine, radyoları ise otomatik olarak yeni açtığımız "Radyo" kategorisine tek tıkla hatasızca dağıtıp veritabanına kaydetmeli.



---

Lütfen bu değişiklikleri mevcut mimariyi bozmadan, temiz ve modüler bir şekilde koda dök.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://tgdizifilm.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/7ace61d1-7da3-4cbf-a857-9648351b5f57).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
