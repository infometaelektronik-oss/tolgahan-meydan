# Uygulamanın tam kontrolü sende: Ana Sayfa Düzenleyici + Kanal/İçerik Yöneticisi

## Sorularının cevabı

- **Türk kanalları silinmedi.** Veritabanında 167 çalışan Türk kanalı duruyor (ATV, Kanal D, Star, Show, TRT…). Sorun şuydu: uygulama tek seferde en fazla 1000 kayıt okuyordu, 4.289 yabancı kanal listeyi doldurunca Türk kanallarının çoğu dışarıda kalıyordu. Bu hata düzeltildi: artık tüm kanallar okunuyor ve Türk kanalları her zaman en başta geliyor.
- **Diziler ve filmler neden gelmiyor:** Veritabanında şu an **0 dizi, 0 film** var. ATV, Kanal D, Star, Show, NOW sitelerindeki videolar korumalı (şifreli ve süreli adresler), bu yüzden tarayıcı her taramada "0 yeni kayıt" buluyor. Korsan dizi siteleri de telifli içerik olduğu için otomatik çekilemez. iptv-org listelerindeki "Dizi" ve "Sinema" bölümleri de film arşivi değil, sadece canlı kanal.
- **Gerçek çözüm:** Dizi ve filmleri, yayın hakkı sende olan kaynaklardan (kendi Replit sunucun, kendi M3U/MP4 adreslerin) senin eklemen. Aşağıdaki panel bunu kolaylaştırıyor.

## Yapılacaklar

### 1. Sahte örnek içerikleri tamamen kaldırma
- Uygulamaya sabit yazılmış örnek kanalları, filmleri ve yayın akışını (Veliaht vb.) siliyorum. Ana sayfada, Canlı TV'de, Arama'da ve Yayın Akışı'nda sadece senin veritabanındaki gerçek içerikler görünecek.

### 2. Ana Sayfa Düzenleyici (admin panelinde yeni "Ana Sayfa" sekmesi)
- **Şeritleri sen oluşturursun:** "ATV Dizileri", "Ulusal Kanallar", "Spor", "Almanya Kanalları"… adını sen koyarsın.
- **Her şeride ne gireceğini sen seçersin:** iki yol var:
  - **Elle seçim:** kanal veya içerik ara, şeride ekle, oklarla sırala, çıkar.
  - **Otomatik kural:** "Kategori = Canlı TV ve Ülke = Türkiye ve Alt kategori = Ulusal" gibi. Kurala uyan yeni kayıtlar kendiliğinden girer.
- Şeritleri yukarı/aşağı taşı, gizle/göster, sil. Hero (üstteki büyük afiş) için hangi içeriklerin döneceğini de sen seçersin.
- Benim koyduğum sabit şeritler (Popüler Diziler, Yabancı Kanallar, Trend…) kalkar; sadece senin oluşturduğun şeritler görünür. Başlangıç için mevcut düzene benzeyen hazır şeritler oluşturulur, sonra istediğin gibi silip düzenlersin.

### 3. Kanal/İçerik Yöneticisi (Kart Yönetimi'nin güçlendirilmiş hali)
- Her kayıt için düzenlenebilir alanlar: ad, kategori (Canlı TV / Dizi / Film / Radyo), alt kategori, **ülke**, yerli/yabancı, logo/afiş, dizi adı, sezon, bölüm, aktif/pasif.
- Filtreler: kategori, ülke, yerli/yabancı, aktif/karantina, arama.
- Toplu işlem: seçilenlerin ülkesini/kategorisini değiştir, şeride ekle, kalıcı sil.
- Kalıcı silme: çöp kutusuna gerek kalmadan tek tıkla tamamen silme seçeneği.

### 4. Otomatik sistemin sana karışmaması
- Ülke/kategori/yerli-yabancı alanını elle değiştirdiğin bir kaydı tarayıcı ve otomatik kurallar **bir daha değiştirmez** ("elle kilitlendi" işareti).
- Otomatik tarayıcı varsayılan olarak sadece **karantinaya** ekler; sen onaylamadan hiçbir şey ana sayfaya düşmez. İstersen tarayıcıyı tamamen kapatabileceğin bir anahtar eklenir.

## Teknik detaylar
- Yeni tablolar: `home_rows` (title, position, enabled, mode `manual|rule`, rule jsonb, limit) ve `home_row_items` (row_id, stream_id, position). Herkes okuyabilir, sadece admin yazar (has_role). `layout_sections` yerine bunlar kullanılır.
- `user_streams.manual_lock boolean`: automation.server, media-classifier, normalizer ve scraper güncellemeleri kilitli kayıtları atlar.
- `data.ts` içindeki `channels`, `movies`, `schedules` dizileri kaldırılır; index.tsx, LiveTV, SearchView, Schedule sadece veritabanını kullanır.
- Ana sayfa: tek server fn `getHomeLayout` şeritleri, manuel öğeleri ve kural eşleşmelerini sunucuda çözüp döndürür (istemciye 4.000+ kayıt gönderilmez).
- Admin server fn'leri `requireSupabaseAuth` + admin rol kontrolü ile korunur.
- Tarayıcı ayarı: `app_settings` tablosu (scraper_enabled, auto_publish).
