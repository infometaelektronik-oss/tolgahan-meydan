# Roadmap

- [x] Türk kanallarının 1000 kayıt sınırında kaybolması düzeltildi
- [x] Sahte örnek içerikleri kaldır
- [x] Ana sayfa şeritleri, şerit içerikleri, ayarlar, elle kilit
- [x] Ana sayfa yalnızca admin şeritlerini gösterir
- [x] Admin "Ana Sayfa" sekmesi
- [x] İçerik Yöneticisi
- [x] Otomasyonlar kilitli kayıtları atlar; tarayıcı aç/kapa + otomatik yayın anahtarı
- [ ] Yanlışlıkla "Türkiye" işaretlenmiş yabancı kanallar — kullanıcı İçerik Yöneticisi'nden düzeltecek ya da toplu temizlik isteyecek
