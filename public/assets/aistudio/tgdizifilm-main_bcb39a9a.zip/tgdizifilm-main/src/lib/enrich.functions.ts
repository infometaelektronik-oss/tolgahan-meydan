import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

type Enriched = {
  title: string;
  posterUrl?: string;
  backdropUrl?: string;
  summary?: string;
  nextAirDate?: string;
  network?: string;
  source: "wikipedia" | "ai" | "wikipedia+ai" | "none";
};

async function wikipediaSummary(title: string): Promise<Partial<Enriched> | null> {
  // Try Turkish wiki first, then English fallback.
  const langs = ["tr", "en"];
  for (const lang of langs) {
    try {
      const slug = encodeURIComponent(title.replace(/\s+/g, "_"));
      const r = await fetch(
        `https://${lang}.wikipedia.org/api/rest_v1/page/summary/${slug}`,
        { headers: { accept: "application/json" } },
      );
      if (!r.ok) continue;
      const j = (await r.json()) as {
        type?: string;
        extract?: string;
        thumbnail?: { source?: string };
        originalimage?: { source?: string };
      };
      if (j.type === "disambiguation") continue;
      const poster = j.originalimage?.source || j.thumbnail?.source;
      if (!poster && !j.extract) continue;
      return {
        posterUrl: poster,
        backdropUrl: poster,
        summary: j.extract,
      };
    } catch {
      // swallow & try next
    }
  }
  return null;
}

async function aiBroadcast(title: string): Promise<Partial<Enriched> | null> {
  const key = process.env.LOVABLE_API_KEY;
  if (!key) return null;
  try {
    const r = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          {
            role: "system",
            content:
              "Sen Türk televizyon dizileri için yayın bilgisi sağlayan bir asistansın. SADECE geçerli JSON döndür.",
          },
          {
            role: "user",
            content: `"${title}" adlı Türk dizisinin yayınlandığı kanal ve haftalık yayın günü/saatini ver. JSON şeması: {"network": string, "nextAirDate": string}. nextAirDate Türkçe biçimde (örn: "Salı 20:00") olsun. Bilmiyorsan boş string döndür.`,
          },
        ],
        response_format: { type: "json_object" },
        temperature: 0.2,
      }),
    });
    if (!r.ok) return null;
    const j = (await r.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const raw = j.choices?.[0]?.message?.content ?? "{}";
    const parsed = JSON.parse(raw) as { network?: string; nextAirDate?: string };
    return {
      network: parsed.network || undefined,
      nextAirDate: parsed.nextAirDate || undefined,
    };
  } catch {
    return null;
  }
}

// Only signed-in callers may trigger the paid AI gateway call; anonymous
// visitors still get the free Wikipedia enrichment used by the public home page.
async function isAuthenticatedCaller(): Promise<boolean> {
  try {
    const { getRequest } = await import("@tanstack/react-start/server");
    const request = getRequest();
    const authHeader = request?.headers?.get("authorization") ?? "";
    if (!authHeader.startsWith("Bearer ")) return false;
    const token = authHeader.slice("Bearer ".length).trim();
    if (!token) return false;
    const url = process.env.SUPABASE_URL;
    const key = process.env.SUPABASE_PUBLISHABLE_KEY;
    if (!url || !key) return false;
    const { createClient } = await import("@supabase/supabase-js");
    const client = createClient(url, key, {
      auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
      global: { headers: { Authorization: `Bearer ${token}` } },
    });
    const { data, error } = await client.auth.getClaims(token);
    return !error && Boolean(data?.claims?.sub);
  } catch {
    return false;
  }
}

export const enrichTitle = createServerFn({ method: "POST" })
  .inputValidator((d) => z.object({ title: z.string().trim().min(1).max(160) }).parse(d))
  .handler(async ({ data }): Promise<Enriched> => {
    const authed = await isAuthenticatedCaller();
    const [wiki, ai] = await Promise.all([
      wikipediaSummary(data.title),
      authed ? aiBroadcast(data.title) : Promise.resolve(null),
    ]);
    const source: Enriched["source"] = wiki && ai ? "wikipedia+ai" : wiki ? "wikipedia" : ai ? "ai" : "none";
    return {
      title: data.title,
      posterUrl: wiki?.posterUrl,
      backdropUrl: wiki?.backdropUrl,
      summary: wiki?.summary,
      network: ai?.network,
      nextAirDate: ai?.nextAirDate,
      source,
    };
  });
