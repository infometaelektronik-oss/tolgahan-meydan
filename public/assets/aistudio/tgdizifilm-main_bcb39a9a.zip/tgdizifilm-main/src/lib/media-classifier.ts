export type StreamCategory = "Live TV" | "Series" | "Movies" | "Radio";
export type StreamType = "HLS" | "MP4" | "AUDIO";
export type StreamStatus = "unknown" | "active" | "degraded" | "dead";
export type SubCategory =
  | "Ulusal" | "Haber" | "Sinema" | "Belgesel" | "Spor" | "Çocuk" | "Müzik" | "Diğer";

const RADIO_HINTS =
  /\b(radyo|radio|fm|am\b|podcast|kral pop|kral fm|kral world|power fm|metro fm|virgin|joy|alem|slow|jazz|klasik|haber\s*radyo)\b/i;
const AUDIO_EXT = /\.(aac|mp3|ogg|m4a)(?:\?|$)/i;
// Only a real on-demand media file can be a movie/episode. Everything else that
// streams continuously is a live channel.
const VOD_EXT = /\.(mp4|mkv|avi|mov|webm)(?:\?|$)/i;

/** Turkish signals in title / group / url. */
const TR_HINTS =
  /(?:^|[^a-z0-9])(t[uü]rk|turkiye|türkiye|ulusal|trt|atv|kanal ?d|show ?tv|star ?tv|now ?tv|fox ?tv|tv ?8|beyaz ?tv|halk ?tv|habert[uü]rk|ntv|a ?haber|teve2|kanal ?7|tgrt|s[oö]zc[uü]|dizi|b[oö]l[uü]m)(?=$|[^a-z0-9])|\.tr\//i;

/** channel_group values from IPTV playlists that are genres, not countries. */
const NON_COUNTRY_GROUPS = new Set(
  [
    "news", "music", "movies", "sports", "series", "kids", "general", "undefined",
    "movies;series", "animation;kids", "classic;series", "documentary", "entertainment",
    "vod movies (en)", "bilinmiyor",
  ],
);

/** English → Turkish country labels for the "Yabancı Kanallar" rows. */
export const COUNTRY_TR: Record<string, string> = {
  Italy: "İtalya", UK: "İngiltere", "United Kingdom": "İngiltere", USA: "ABD",
  "United States": "ABD", Germany: "Almanya", France: "Fransa", Spain: "İspanya",
  Greece: "Yunanistan", Russia: "Rusya", Ukraine: "Ukrayna", Hungary: "Macaristan",
  "Czech Republic": "Çekya", Poland: "Polonya", Romania: "Romanya", Bulgaria: "Bulgaristan",
  Netherlands: "Hollanda", Belgium: "Belçika", Portugal: "Portekiz", Sweden: "İsveç",
  Norway: "Norveç", Finland: "Finlandiya", Denmark: "Danimarka", Austria: "Avusturya",
  Switzerland: "İsviçre", Canada: "Kanada", Brazil: "Brezilya", Argentina: "Arjantin",
  Chile: "Şili", Mexico: "Meksika", India: "Hindistan", China: "Çin", Korea: "Kore",
  "South Korea": "Güney Kore", Japan: "Japonya", "日本 / Japan": "Japonya",
  "United Arab Emirates": "BAE", Egypt: "Mısır", "Saudi Arabia": "Suudi Arabistan",
  Azerbaijan: "Azerbaycan", "North Macedonia": "Kuzey Makedonya", Albania: "Arnavutluk",
  Serbia: "Sırbistan", Croatia: "Hırvatistan", Bosnia: "Bosna", Mongolia: "Moğolistan",
  Iran: "İran", Iraq: "Irak", Israel: "İsrail", Australia: "Avustralya",
  Türkiye: "Türkiye", Turkey: "Türkiye",
};

export function countryLabel(country?: string | null): string {
  if (!country) return "Diğer Ülkeler";
  return COUNTRY_TR[country] || country;
}

/** Detects the broadcast country from playlist metadata. */
export function detectCountry(
  title: string,
  sourceUrl: string,
  groupTitle?: string | null,
): { country: string | null; isForeign: boolean } {
  const haystack = `${title} ${groupTitle || ""} ${sourceUrl}`;
  if (TR_HINTS.test(haystack)) return { country: "Türkiye", isForeign: false };
  const group = (groupTitle || "").trim();
  if (!group) return { country: null, isForeign: true };
  const normalized = group.replace(/^VOD\s+/i, "").trim();
  if (NON_COUNTRY_GROUPS.has(normalized.toLowerCase())) return { country: null, isForeign: true };
  return { country: normalized, isForeign: normalized !== "Türkiye" };
}

export function classify(
  title: string,
  sourceUrl: string,
  groupTitle?: string,
): {
  category: StreamCategory;
  streamType: StreamType;
  tags: string[];
  country: string | null;
  isForeign: boolean;
} {
  const haystack = `${title} ${sourceUrl} ${groupTitle || ""}`.toLowerCase();
  const path = (() => {
    try {
      return new URL(sourceUrl).pathname.toLowerCase();
    } catch {
      return sourceUrl.toLowerCase();
    }
  })();
  const isAudioExt = AUDIO_EXT.test(path);
  const isVodFile = VOD_EXT.test(path);
  const streamType: StreamType = isAudioExt
    ? "AUDIO"
    : path.endsWith(".m3u8")
      ? "HLS"
      : "MP4";

  const seriesHints = ["sezon", "season", "episode", "bölüm", "bolum", "s01e", "s02e"];
  const isRadio = isAudioExt || RADIO_HINTS.test(haystack);
  const looksSeries = seriesHints.some((h) => haystack.includes(h));

  // Live channels can never fall into Movies/Series — only real VOD files do.
  const category: StreamCategory = isRadio
    ? "Radio"
    : isVodFile
      ? looksSeries
        ? "Series"
        : "Movies"
      : "Live TV";

  const { country, isForeign } = detectCountry(title, sourceUrl, groupTitle);

  const tags = [
    streamType,
    category,
    ...(country ? [country] : []),
    ...haystack
      .split(/[^a-z0-9ğüşöçıİĞÜŞÖÇ]+/i)
      .filter((x) => x.length > 3)
      .slice(0, 6),
  ];
  return { category, streamType, tags: Array.from(new Set(tags)), country, isForeign };
}
