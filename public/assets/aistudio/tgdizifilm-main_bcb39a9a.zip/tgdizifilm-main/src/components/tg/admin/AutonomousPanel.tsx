import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Bot, Globe2, Loader2, Play, Plus, Power, Trash2, Zap } from "lucide-react";
import {
  addScraperSeed,
  bootstrapAndRun,
  deleteScraperSeed,
  listScraperSeeds,
  runAutonomousNow,
  toggleScraperSeed,
  type SeedRow,
} from "@/lib/autonomous.functions";

export function AutonomousPanel({ onChanged }: { onChanged?: () => void }) {
  const listFn = useServerFn(listScraperSeeds);
  const addFn = useServerFn(addScraperSeed);
  const delFn = useServerFn(deleteScraperSeed);
  const toggleFn = useServerFn(toggleScraperSeed);
  const runFn = useServerFn(runAutonomousNow);
  const bootstrapRunFn = useServerFn(bootstrapAndRun);


  const [seeds, setSeeds] = useState<SeedRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [log, setLog] = useState<string[]>([]);
  const [newUrl, setNewUrl] = useState("");
  const [newHint, setNewHint] = useState("");

  const refresh = async () => {
    setLoading(true);
    try {
      setSeeds(await listFn());
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const append = (line: string) => setLog((prev) => [`[${new Date().toLocaleTimeString()}] ${line}`, ...prev].slice(0, 30));

  const handleRun = async () => {
    setRunning(true);
    append("URL-Specter otonom tarama başlatıldı…");
    try {
      const res = await runFn({ data: { batchSize: 3 } });
      append(
        `Tamamlandı — ${res.processedSeeds} tohum işlendi, ${res.savedItems} yeni öğe karantinaya alındı, ${res.failed} hata.` +
          (res.savedItems === 0 && res.failed === 0 ? " Kaynaklardaki yayınlar zaten kayıtlı." : ""),
      );
      res.errors?.forEach((e) => append(`⚠ ${e}`));
      onChanged?.();
      refresh();
    } catch (e) {
      append(`Hata: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setRunning(false);
    }
  };

  const handleBootstrap = async () => {
    setRunning(true);
    append("🌍 Kamuya açık Türkiye IPTV kaynakları ekleniyor + tam tarama başlıyor…");
    try {
      const res = await bootstrapRunFn({ data: undefined });
      append(
        `✓ ${res.bootstrapped} kaynak hazır · ${res.processedSeeds} tohum tarandı · ${res.savedItems} yeni yayın karantinada · ${res.failed} hata.` +
          (res.savedItems === 0 && res.failed === 0 ? " Yayınlar daha önce kaydedilmiş." : ""),
      );
      res.errors?.forEach((e) => append(`⚠ ${e}`));
      onChanged?.();
      refresh();
    } catch (e) {
      append(`Bootstrap hatası: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setRunning(false);
    }
  };




  const handleAdd = async () => {
    if (!newUrl.trim()) return;
    try {
      await addFn({ data: { url: newUrl.trim(), hint: newHint.trim() || undefined } });
      setNewUrl(""); setNewHint("");
      append(`Tohum eklendi: ${newUrl}`);
      refresh();
    } catch (e) {
      append(`Ekleme hatası: ${e instanceof Error ? e.message : String(e)}`);
    }
  };

  return (
    <div className="space-y-5">
      <div className="rounded-3xl border border-emerald-500/30 bg-gradient-to-br from-emerald-950/60 to-slate-900/60 p-5">
        <div className="mb-4 flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-emerald-500/25 text-emerald-200">
              <Bot className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-lg font-black text-emerald-100">Tam Otonom Sistem (URL-Specter)</h3>
              <p className="text-xs text-white/60">
                Kullanıcı link girmez. Sistem, aşağıdaki tohum URL'leri her 15 dk'da bir otomatik tarar,
                Chrome kamuflajıyla indirir, M3U/HLS/MP4 adaylarını çıkarır ve karantinaya yazar.
                Sağlık kontrolünden geçenler yayına alınır.
              </p>
            </div>
          </div>
          <div className="flex flex-col gap-2 sm:flex-row">
            <button
              onClick={handleBootstrap}
              disabled={running}
              className="flex items-center gap-2 rounded-2xl bg-cyan-400 px-5 py-3 font-black text-black disabled:opacity-50"
              title="Kamuya açık Türkiye IPTV kaynaklarını ekle ve hemen tara"
            >
              {running ? <Loader2 className="h-4 w-4 animate-spin" /> : <Globe2 className="h-4 w-4" />}
              🌍 Otomatik Kaynak Bul & Tara
            </button>
            <button
              onClick={handleRun}
              disabled={running}
              className="flex items-center gap-2 rounded-2xl bg-emerald-500 px-5 py-3 font-black text-black disabled:opacity-50"
            >
              {running ? <Loader2 className="h-4 w-4 animate-spin" /> : <Zap className="h-4 w-4" />}
              {running ? "Taranıyor…" : "Şimdi Tara"}
            </button>
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-[1fr_200px_auto]">
          <input
            value={newUrl}
            onChange={(e) => setNewUrl(e.target.value)}
            placeholder="Yeni tohum URL (https://…)"
            className="rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm"
          />
          <input
            value={newHint}
            onChange={(e) => setNewHint(e.target.value)}
            placeholder="İpucu (opsiyonel)"
            className="rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-sm"
          />
          <button onClick={handleAdd} className="flex items-center gap-2 rounded-xl bg-white/10 px-4 py-2 text-sm font-bold hover:bg-white/15">
            <Plus className="h-4 w-4" /> Tohum Ekle
          </button>
        </div>
      </div>

      {/* Log */}
      {log.length > 0 && (
        <div className="rounded-2xl border border-white/10 bg-black/60 p-4 font-mono text-xs">
          <div className="mb-2 flex items-center gap-2 text-emerald-300">
            <Play className="h-3 w-3" /> Canlı Kayıt
          </div>
          <div className="max-h-48 space-y-1 overflow-auto">
            {log.map((l, i) => <div key={i} className="text-white/70">{l}</div>)}
          </div>
        </div>
      )}

      {/* Seeds list */}
      <div className="rounded-2xl border border-white/10 bg-white/5">
        <div className="border-b border-white/10 px-4 py-3 text-sm font-bold">
          Tohum URL'ler ({seeds.length})
        </div>
        {loading ? (
          <div className="p-6 text-center text-white/60">Yükleniyor…</div>
        ) : seeds.length === 0 ? (
          <div className="p-6 text-center text-white/60">Henüz tohum yok. Yukarıdan ekle.</div>
        ) : (
          <div className="divide-y divide-white/5">
            {seeds.map((s) => (
              <div key={s.id} className={`grid grid-cols-[1fr_auto] items-center gap-3 px-4 py-3 text-sm ${s.disabled ? "opacity-50" : ""}`}>
                <div className="min-w-0">
                  <div className="truncate font-mono text-xs text-white/90">{s.url}</div>
                  <div className="mt-1 flex flex-wrap gap-2 text-[10px] text-white/50">
                    {s.hint && <span className="rounded bg-white/5 px-1.5 py-0.5">{s.hint}</span>}
                    {s.force_category && <span className="rounded bg-purple-500/20 px-1.5 py-0.5 text-purple-200">{s.force_category}</span>}
                    <span>öncelik {s.priority}</span>
                    <span className="text-emerald-300">✓ {s.success_count}</span>
                    <span className="text-red-300">✗ {s.failure_count}</span>
                    {s.last_scanned_at && <span>son: {new Date(s.last_scanned_at).toLocaleString()}</span>}
                    {s.last_error && <span className="text-red-300">hata: {s.last_error.slice(0, 60)}</span>}
                  </div>
                </div>
                <div className="flex gap-1">
                  <button
                    onClick={async () => { await toggleFn({ data: { id: s.id, disabled: !s.disabled } }); refresh(); }}
                    className="rounded-lg bg-white/5 p-2 hover:bg-white/10"
                    title={s.disabled ? "Etkinleştir" : "Devre dışı"}
                  >
                    <Power className={`h-4 w-4 ${s.disabled ? "text-white/40" : "text-emerald-300"}`} />
                  </button>
                  <button
                    onClick={async () => { if (confirm("Sil?")) { await delFn({ data: { id: s.id } }); refresh(); } }}
                    className="rounded-lg bg-white/5 p-2 hover:bg-red-500/20"
                  >
                    <Trash2 className="h-4 w-4 text-red-300" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
