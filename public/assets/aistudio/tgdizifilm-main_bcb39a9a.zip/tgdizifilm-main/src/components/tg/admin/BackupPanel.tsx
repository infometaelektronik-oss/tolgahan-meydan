import { useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Download, Loader2, Upload } from "lucide-react";
import { exportBackup, importBackup } from "@/lib/admin-ops.functions";

export function BackupPanel({ onChanged }: { onChanged: () => void }) {
  const exportFn = useServerFn(exportBackup);
  const importFn = useServerFn(importBackup);
  const fileRef = useRef<HTMLInputElement>(null);

  const [busy, setBusy] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [activate, setActivate] = useState(false);

  const download = async (format: "json" | "m3u") => {
    setBusy(format);
    setNote(null);
    try {
      const res = await exportFn({ data: { format } });
      const blob = new Blob([res.content], {
        type: format === "json" ? "application/json" : "audio/x-mpegurl",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `tgdizifilm-yedek-${new Date().toISOString().slice(0, 10)}.${format}`;
      a.click();
      URL.revokeObjectURL(url);
      setNote(`${res.count} içerik dışa aktarıldı.`);
    } catch (e) {
      setNote(e instanceof Error ? e.message : "Dışa aktarılamadı");
    } finally {
      setBusy(null);
    }
  };

  const onFile = async (file: File) => {
    setBusy("import");
    setNote(null);
    try {
      const content = await file.text();
      const res = await importFn({ data: { content, activateStreams: activate } });
      setNote(
        `Geri yüklendi → ${res.streams} yayın, ${res.seeds} tohum, ${res.layout} şerit.`,
      );
      onChanged();
    } catch (e) {
      setNote(e instanceof Error ? e.message : "Geri yüklenemedi");
    } finally {
      setBusy(null);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  return (
    <section className="rounded-3xl border border-purple-500/20 bg-white/5 p-5 backdrop-blur">
      <h3 className="text-lg font-black">Yedekleme &amp; Dışa Aktarma</h3>
      <p className="mt-1 text-xs text-white/50">
        Tüm kanallar, tohum adresleri, kategori ağacı ve ana sayfa düzeni tek dosyada.
      </p>

      <div className="mt-4 grid gap-3 md:grid-cols-2">
        <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
          <div className="text-sm font-black text-white">Dışa aktar</div>
          <div className="mt-3 flex flex-wrap gap-2">
            <button
              onClick={() => download("json")}
              disabled={busy !== null}
              className="flex items-center gap-2 rounded-xl bg-purple-600 px-4 py-2 text-xs font-black text-white disabled:opacity-40"
            >
              {busy === "json" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
              JSON yedeği indir
            </button>
            <button
              onClick={() => download("m3u")}
              disabled={busy !== null}
              className="flex items-center gap-2 rounded-xl bg-white/10 px-4 py-2 text-xs font-black text-white disabled:opacity-40"
            >
              {busy === "m3u" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
              M3U listesi indir
            </button>
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
          <div className="text-sm font-black text-white">Geri yükle</div>
          <label className="mt-3 flex items-center gap-2 text-xs text-white/70">
            <input
              type="checkbox"
              checked={activate}
              onChange={(e) => setActivate(e.target.checked)}
            />
            Geri yüklenen tüm yayınları hemen yayına al
          </label>
          <input
            ref={fileRef}
            type="file"
            accept=".json,application/json"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onFile(f);
            }}
          />
          <button
            onClick={() => fileRef.current?.click()}
            disabled={busy !== null}
            className="mt-3 flex items-center gap-2 rounded-xl bg-emerald-600/80 px-4 py-2 text-xs font-black text-white disabled:opacity-40"
          >
            {busy === "import" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
            JSON yedeği yükle
          </button>
        </div>
      </div>

      {note && <div className="mt-4 text-xs text-purple-200">{note}</div>}
    </section>
  );
}
