import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Copy, Film, Gauge, Loader2, Sparkles, Wrench } from "lucide-react";
import {
  runAiNormalizer,
  runDeduplication,
  runQualityScan,
  runSelfHealing,
  runMetadataEnrichment,
} from "@/lib/smart-admin.functions";

export function SmartToolsPanel({ onChanged }: { onChanged?: () => void }) {
  const normalizeFn = useServerFn(runAiNormalizer);
  const healFn = useServerFn(runSelfHealing);
  const dedupeFn = useServerFn(runDeduplication);
  const qualityFn = useServerFn(runQualityScan);
  const metaFn = useServerFn(runMetadataEnrichment);

  const [busy, setBusy] = useState<string | null>(null);
  const [log, setLog] = useState<string[]>([]);
  const [minHeight, setMinHeight] = useState(480);

  const append = (line: string) =>
    setLog((prev) => [`[${new Date().toLocaleTimeString()}] ${line}`, ...prev].slice(0, 40));

  const run = async (key: string, fn: () => Promise<string>) => {
    setBusy(key);
    try {
      append(await fn());
      onChanged?.();
    } catch (e) {
      append(`Hata: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setBusy(null);
    }
  };

  const cards = [
    {
      key: "meta",
      icon: Film,
      title: "Otomatik Meta-Veri (TMDB / AI)",
      desc: "Sadece ismi olan film ve dizilere kapak, konu, çıkış yılı, IMDB puanı ve oyuncu kadrosu ekler.",
      color: "from-violet-950/60",
      border: "border-violet-500/30",
      button: "bg-violet-400",
      action: async () => {
        const r = await metaFn({ data: undefined });
        return `Meta-veri · ${r.updated}/${r.scanned} içerik zenginleştirildi (${r.source})`;
      },
    },
    {
      key: "normalize",
      icon: Sparkles,
      title: "AI İsim Temizleme & Logolama",
      desc: "TR_ATV_1080p_v3 gibi karmaşık isimleri ATV HD şekline getirir, uygun logoyu otomatik eşler.",
      color: "from-fuchsia-950/60",
      border: "border-fuchsia-500/30",
      button: "bg-fuchsia-400",
      action: async () => {
        const r = await normalizeFn({ data: { limit: 40 } });
        r.samples.forEach((s) => append(`  ${s.from} → ${s.to}`));
        return `İsim temizleme bitti · ${r.updated}/${r.scanned} kayıt düzeltildi · ${r.logosMatched} logo eşlendi${r.usedAi ? "" : " (kural motoru)"}`;
      },
    },
    {
      key: "heal",
      icon: Wrench,
      title: "Kendi Kendini Onaran Yayın",
      desc: "Patlamış yayınlar için diğer kaynaklardan çalışan alternatif adresi bulup ana yayına atar.",
      color: "from-emerald-950/60",
      border: "border-emerald-500/30",
      button: "bg-emerald-400",
      action: async () => {
        const r = await healFn({ data: undefined });
        r.samples.forEach((s) => append(`  ${s}`));
        return `Onarma bitti · ${r.broken} bozuk · ${r.healed} onarıldı · ${r.noAlternative} alternatifsiz`;
      },
    },
    {
      key: "dedupe",
      icon: Copy,
      title: "Mükerrer İçerik Birleştirici",
      desc: "Aynı isimli yayınları tek başlık altında toplar, diğerlerini yedek kaynak olarak bağlar.",
      color: "from-sky-950/60",
      border: "border-sky-500/30",
      button: "bg-sky-400",
      action: async () => {
        const r = await dedupeFn({ data: undefined });
        r.samples.forEach((s) => append(`  ${s}`));
        return `Birleştirme bitti · ${r.groups} grup · ${r.merged} yedek kaynak bağlandı`;
      },
    },
    {
      key: "quality",
      icon: Gauge,
      title: "Kalite Ölçümü & Otomatik Filtre",
      desc: `Çözünürlük, bit hızı ve FPS ölçülür; ${minHeight}p altındaki yayınlar otomatik pasife alınır.`,
      color: "from-amber-950/60",
      border: "border-amber-500/30",
      button: "bg-amber-400",
      action: async () => {
        const r = await qualityFn({ data: { limit: 40, minHeight } });
        return `Kalite taraması · ${r.checked} yayın · ${r.measured} ölçüldü · ${r.deactivated} düşük kaliteli pasife alındı`;
      },
    },
  ];

  return (
    <div className="space-y-5">
      <div className="grid gap-4 md:grid-cols-2">
        {cards.map((c) => (
          <div key={c.key} className={`rounded-3xl border ${c.border} bg-gradient-to-br ${c.color} to-slate-900/60 p-5`}>
            <div className="flex items-start gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10">
                <c.icon className="h-5 w-5" />
              </div>
              <div className="min-w-0 flex-1">
                <h3 className="text-base font-black">{c.title}</h3>
                <p className="mt-1 text-xs text-white/60">{c.desc}</p>
              </div>
            </div>
            {c.key === "quality" && (
              <div className="mt-4 flex items-center gap-3 text-xs text-white/70">
                <span>Alt kalite sınırı</span>
                <select
                  value={minHeight}
                  onChange={(e) => setMinHeight(Number(e.target.value))}
                  className="rounded-lg border border-white/10 bg-black/50 px-2 py-1"
                >
                  {[360, 480, 720, 1080].map((h) => (
                    <option key={h} value={h}>{h}p</option>
                  ))}
                </select>
              </div>
            )}
            <button
              onClick={() => run(c.key, c.action)}
              disabled={busy !== null}
              className={`mt-4 flex items-center gap-2 rounded-2xl ${c.button} px-4 py-2.5 text-sm font-black text-black disabled:opacity-50`}
            >
              {busy === c.key ? <Loader2 className="h-4 w-4 animate-spin" /> : <c.icon className="h-4 w-4" />}
              {busy === c.key ? "Çalışıyor…" : "Çalıştır"}
            </button>
          </div>
        ))}
      </div>

      {log.length > 0 && (
        <div className="rounded-2xl border border-white/10 bg-black/60 p-4 font-mono text-xs">
          <div className="mb-2 text-emerald-300">Canlı Kayıt</div>
          <div className="max-h-64 space-y-1 overflow-auto">
            {log.map((l, i) => (
              <div key={i} className="text-white/70">{l}</div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
