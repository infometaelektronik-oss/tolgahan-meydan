import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, type UIMessage } from "ai";
import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";

const SYSTEM_PROMPT = `Sen TG. Dizi Film uygulamasının yapay zeka asistanısın.
Türkçe konuşan kullanıcıya kısa, sıcak ve net cevaplar ver.
Görevin: Türk dizileri (Kanal D, Show TV, Star TV, ATV, TRT, FOX, NOW) ve filmler hakkında öneri vermek,
oyuncu/konu/yayın tarihi sormak, kullanıcıyı doğru kategoriye (Canlı TV, Diziler, Filmler) yönlendirmek.

Kullanıcının Türkçe sorusunu ANLAMAK için şu eşleştirmeleri kullan:
- "sinema" / "film" / "vizyon" → Movies / Dram + Aksiyon
- "korku" / "gerilim" → Horror
- "polisiye" / "dedektif" / "cinayet" → Suç / Gerilim dizileri
- "aile" / "çocuk" → Aile filmleri / Animasyon
- "romantik" / "aşk" → Romantik komedi / Dram
- "yerli dizi" / "türk dizisi" → Türk Dizileri
- Kullanıcı "bugün kanald'de ne var" gibi sorsa günün programını sıralayarak öner.

Yasadışı yayın linki PAYLAŞMA. Sadece kullanıcının kendi eklediği kaynakları ya da resmi yayıncı sitelerini tavsiye et.
Cevaplarını markdown ile, gerekiyorsa madde imleriyle ver. En fazla 5 öneri, en fazla 8 satır.`;

type ChatRequestBody = { messages?: unknown };

// Basit IP başına sliding window rate limit (worker-instance memory)
const RATE_WINDOW_MS = 60_000;
const RATE_MAX = 20;
const hits = new Map<string, number[]>();
function rateLimit(ip: string): boolean {
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < RATE_WINDOW_MS);
  if (list.length >= RATE_MAX) {
    hits.set(ip, list);
    return false;
  }
  list.push(now);
  hits.set(ip, list);
  // sızıntıyı engellemek için ara ara temizle
  if (hits.size > 5000) {
    for (const [k, v] of hits) if (!v.some((t) => now - t < RATE_WINDOW_MS)) hits.delete(k);
  }
  return true;
}

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const ip =
          request.headers.get("cf-connecting-ip") ||
          request.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
          "unknown";
        if (!rateLimit(ip)) {
          return new Response(JSON.stringify({ error: "Çok hızlı! 1 dakika bekle." }), {
            status: 429,
            headers: { "content-type": "application/json", "retry-after": "60" },
          });
        }
        const { messages } = (await request.json()) as ChatRequestBody;
        if (!Array.isArray(messages)) {
          return new Response("Messages are required", { status: 400 });
        }
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const gateway = createLovableAiGatewayProvider(key);
        const result = streamText({
          model: gateway("google/gemini-3-flash-preview"),
          system: SYSTEM_PROMPT,
          messages: await convertToModelMessages(messages as UIMessage[]),
        });

        return result.toUIMessageStreamResponse({
          originalMessages: messages as UIMessage[],
        });
      },
    },
  },
});

