# Project rules

- Home page content comes only from `home_rows` / `home_row_items` resolved server-side by `getHomeLayout`; never hardcode rows or sample media in the client. Why: the admin must fully control what appears and in which order.
- Rows edited by the admin get `user_streams.manual_lock = true`; every automation (rules, normalizer, metadata, self-heal, series repair) must filter `manual_lock = false`. Why: automation must never override admin decisions.
- Reads of `user_streams` that can exceed 1000 rows must page with `.range()`. Why: the database caps responses at 1000 rows and silently truncates.
- The scraper reads `app_settings` (`scraper_enabled`, `auto_publish`) at the start of each run. Why: the admin can switch it off or require approval without code changes.
